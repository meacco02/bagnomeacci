/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bagnomeacci;

/**
 *
 * @author informatica
 */
class Semaforo {

    public Semaforo semaforo;

    public Semaforo (int slotLimit) {
       semaforo = new Semaforo(slotLimit);
    }

    public Semaforo(Semaforo semaforo) {
        this.semaforo = semaforo;
    }

    boolean tryLogin() {
        return semaforo.tryAcquire();
    }

    void logout() {
        semaforo.release();
    }

    int availableSlots() {
        return semaforo.availablePermits();
    }

   
    
    
    
    
    
    
    private int availablePermits() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void release() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private boolean tryAcquire() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
