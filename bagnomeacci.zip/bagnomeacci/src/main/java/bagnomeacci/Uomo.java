/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bagnomeacci;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author informatica
 */
    
public class Uomo extends Thread{

    Bagno t;

Random r; // durata casuale del bagno

public Uomo(Bagno T, Random R){

    this.t=T;

this.r=R;
}

    Uomo() {
        
       
    }
@Override


public void run(){ try {
    //in questo momento usiamo il metodo sleep
    
    
    
    Thread.sleep(r.nextInt(5)*1000);
    t.usa_Bagno(getName(), r);
    } 
   

catch (InterruptedException ex) {
        Logger.getLogger(Uomo.class.getName()).log(Level.SEVERE, null, ex);
    }
  //questo serve per chiudere il ciclo

}


}


