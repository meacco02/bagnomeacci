/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bagnomeacci;

import java.util.Random;

/**
 *
 * @author informatica
 */
public class Bagno {

   
    public static void Bagno(String[] args) {
        
   Bagno b1= new Bagno (); // inizializzazione oggetti
   Bagno b2= new Bagno ();
   
   
   Uomo u1= new Uomo();
   Uomo u2= new Uomo();
   Uomo u3= new Uomo();
   Donna d1= new Donna();
   Donna d2= new Donna();
   Donna d3= new Donna();
   
   u1.start(); // start uomini
   u2.start(); 
   u3.start();
   
   d1.start();// start donne 
   d2.start();
   d3.start();
  
   b1.start(); // start bagno
   b2.start();
   b3.start();
    
    
    
    }

    void usa_Bagno(String name, Random r) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
